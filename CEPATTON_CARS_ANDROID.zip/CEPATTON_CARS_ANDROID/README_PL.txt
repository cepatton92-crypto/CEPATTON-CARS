CEPATTON CARS — projekt Android (źródła)

To jest projekt do otwarcia w Android Studio, a nie gotowy APK.
Wymagania: Android Studio z Android SDK 35, JDK 17, dostęp do internetu przy pierwszej synchronizacji Gradle.

Uruchomienie:
1. Rozpakuj ZIP.
2. Android Studio > Open > wybierz folder CEPATTON_CARS_ANDROID.
3. Poczekaj na synchronizację Gradle.
4. Run na telefonie albo Build > Build APK(s).

Baza obecnie wbudowana offline to starter z 83 rekordami ogólnych kodów OBD-II (w tym duplikat kodu może występować). Nie jest to kompletna baza BMW ani baza wszystkich kodów producenta. Aplikacja pokazuje pola marki/modelu/roku/silnika i wyszukuje lokalnie po kodzie. Wyszukiwanie internetowe otwiera przeglądarkę.

Ważne źródła do dalszego rozszerzania bazy:
- OBDeX (CC0): https://github.com/foerbsnavi/OBDex — 9 533 ogólne kody, opisy EN/DE, źródła; kody OEM są poza zakresem.
- Wal33D/dtc-database (MIT): https://github.com/Wal33D/dtc-database — deklaruje 18 805 definicji, 12 128 unikalnych kodów, 33 marki; wymaga weryfikacji źródeł i jakości opisów.
- Automotive-9/dtc-codes: https://github.com/Automotive-9/dtc-codes — repozytorium deklaruje 4 781 kodów BMW; sprawdzić licencję i pochodzenie danych przed dystrybucją.
- Oficjalne BMW AOS/ISTA: https://bmwtechinfo.bmwgroup.com/ — fabryczne test plany, naprawy, schematy i informacje serwisowe są w systemach BMW; dostęp może wymagać konta/opłat.

Nie dodano numerów OEM ani dopasowania części po VIN. Tych danych nie wolno zgadywać; należy je pobierać z katalogu BMW/ETK lub licencjonowanego źródła. Nie skopiowano chronionych treści serwisowych.
