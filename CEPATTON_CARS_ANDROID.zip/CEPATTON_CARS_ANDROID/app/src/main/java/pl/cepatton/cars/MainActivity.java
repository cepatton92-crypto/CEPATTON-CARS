package pl.cepatton.cars;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    EditText code, make, model, year, engine;
    LinearLayout results;
    JSONArray records;
    int bg = Color.rgb(10,16,29), panel = Color.rgb(21,31,50), blue = Color.rgb(55,145,255);
    @Override public void onCreate(Bundle b) { super.onCreate(b); loadDb(); buildUi(); }
    void loadDb() {
        try (InputStream in=getAssets().open("dtc_database.json")) {
            ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0) out.write(buf,0,n);
            records=new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8)).getJSONArray("records");
        } catch(Exception e) { records=new JSONArray(); }
    }
    TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); t.setPadding(0,6,0,6); return t; }
    EditText field(String hint) { EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(0xff9aa8bd); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); return e; }
    void buildUi() {
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,28,22,28); scroll.addView(root); setContentView(scroll);
        root.addView(text("CEPATTON CARS",28,Color.WHITE,true)); root.addView(text("KATALOG KODÓW USTEREK • OFFLINE",12,0xff7db8ff,true));
        root.addView(text("Wpisz kod i dane samochodu",18,Color.WHITE,true));
        code=field("Kod błędu, np. P0299 lub 123456"); root.addView(code);
        make=field("Marka, np. BMW"); make.setText("BMW"); root.addView(make);
        model=field("Model / seria, np. 320d F30, 530d G30"); root.addView(model);
        year=field("Rok produkcji, np. 2016"); root.addView(year);
        engine=field("Silnik, np. N47, B47, N57, B58"); root.addView(engine);
        Button search=new Button(this); search.setText("SZUKAJ W BAZIE OFFLINE"); search.setTextColor(Color.WHITE); search.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); root.addView(search);
        Button web=new Button(this); web.setText("SZUKAJ DODATKOWO W INTERNECIE"); root.addView(web);
        results=new LinearLayout(this); results.setOrientation(1); results.setPadding(14,14,14,14); results.setBackgroundColor(panel); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.topMargin=20; root.addView(results,rp);
        results.addView(text("Wyniki pojawią się tutaj.",15,Color.WHITE,false));
        search.setOnClickListener(v->find());
        web.setOnClickListener(v->{ String q=code.getText().toString()+" BMW "+model.getText()+" "+year.getText()+" "+engine.getText()+" fault code"; android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse("https://www.google.com/search?q="+android.net.Uri.encode(q))); startActivity(i); });
    }
    void find() {
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(code.getWindowToken(),0);
        String c=code.getText().toString().trim().toUpperCase(); results.removeAllViews();
        results.addView(text("WYNIK WYSZUKIWANIA",18,0xff7db8ff,true));
        results.addView(text("Pojazd: "+make.getText()+" "+model.getText()+" • "+year.getText()+" • "+engine.getText(),13,0xffc8d5e8,false));
        boolean found=false;
        for(int i=0;i<records.length();i++) try { JSONObject r=records.getJSONObject(i); if(r.optString("code").equalsIgnoreCase(c)) { found=true; card(r); } } catch(Exception ignored) {}
        if(!found) results.addView(text("Brak tego kodu w aktualnej bazie offline. Użyj wyszukiwania internetowego lub zaimportuj nowszą bazę w kolejnej wersji.",15,Color.WHITE,false));
        results.addView(text("Uwaga: kod wskazuje obszar usterki, nie zawsze uszkodzoną część. Dla BMW wymagane jest potwierdzenie kodu producenta i test planem ISTA.",12,0xffffcc80,false));
    }
    void card(JSONObject r) {
        results.addView(text(r.optString("code")+" — "+r.optString("name_pl"),17,Color.WHITE,true));
        addSection("Co sprawdzić",r.optString("general_check"));
        addSection("Możliwe przyczyny",join(r.optJSONArray("causes")));
        addSection("Objawy",join(r.optJSONArray("symptoms")));
        addSection("Diagnostyka",r.optString("diagnostic_note"));
        addSection("Naprawa",r.optString("repair_note"));
        addSection("Numer OEM",r.optString("oem_note","Numeru OEM nie podano — dobierz po VIN w katalogu producenta."));
    }
    String join(JSONArray a) { if(a==null)return "Brak danych"; StringBuilder s=new StringBuilder(); for(int i=0;i<a.length();i++)s.append("• ").append(a.optString(i)).append("\n"); return s.toString(); }
    void addSection(String h,String body) { results.addView(text(h,14,0xff7db8ff,true)); results.addView(text(body,14,Color.WHITE,false)); }
}
